# Independent referee checks: Wilhelm–Heinrich v0.3

Review date: 2 October 2026.
Manuscript: *No escape and global cycle uniqueness in a singular wedge of the Wilhelm–Heinrich oscillator*.
Submission archive: evidence_press_wilhelm_heinrich_no_escape_v0_3(1).zip.

## Review conclusion

Recommendation: minor revisions. Provisional overall output-quality calibration: strong 3-star.
No fatal or major mathematical defect was identified in the written proof within its stated bounded singular wedge. This is a mathematical referee assessment, not formal proof-assistant verification or an official REF decision.
The complete review is provided in the accompanying ChatGPT response.

## Scope of the result

For every finite N>0, the manuscript asserts existence of a common sufficiently large S_N such that the original oscillator has exactly one nonconstant positive periodic orbit, up to phase, whenever sigma >= S_N and 0 < nu <= N, with rho=1+nu/sigma^2. The orbit is hyperbolic attracting. Every possible periodic orbit is captured; this is not merely local uniqueness. The result does not cover all parameters or unbounded nu. S_N is not numerically certified.

## Checks actually performed

- Original integrity check: 32/32 file hashes matched before rerunning scripts.
- Author symbolic checks: 32/32 passed.
- Author inherited mesh diagnostics: 12/12 passed.
- Author full-system return tests: 9/9 returned, with all signs matching predictions.
- Independently written exact checks: 17/17 passed.
- Independent selector quadrature: 101 energies from 1e-4 to 1e3; minimum sampled slope 0.8007941479731877. This is diagnostic, not proof of a global bound.
- Independent returns: 9/9, using DOP853 in chemical coordinates instead of the author's scalar-coordinate Radau integration. Maximum relative difference in scaled displacement: 1.6268811592898235e-7.
- Exact Hopf check: d Re(lambda)/d nu at nu=0 is epsilon^3/[2(1+epsilon^2)].
- Mutation test: deliberately reversed the predicted displacement sign in an isolated import of the author's numerical module. The result had sign_matches_prediction=false but passed=true. This is a genuine validation-predicate defect, not a failure of any of the nine submitted signs.

## Main analytical findings

The review checked the general-rate filter reconstruction, exact cubic log-filter balance, support-moment estimate, uniform compact visit, third-order energy calculation, pointwise phase correction, exact vertical-defect equation, inward boundary argument, capture of every periodic orbit, concentration, selector inequality, and the scaled return map at the joint small-amplitude/Hopf endpoint.
The central no-escape argument was judged coherent: the fixed-domain slow graph is constructed before capture; a compact visit is not confused with a uniform bound; the vertical defect contracts exactly rather than only after linearisation; periodicity forces graph membership.

## Required/bounded revisions

1. State the precise compact persistence input and track the finite differentiability retained through Taylor/Hadamard divisions. The construction appears valid; this request is for proof traceability, not a newly identified gap.
2. Add direct references to Wilhelm and Heinrich (1995, 1996), comparing the published local Hopf result, Smith's global convergence result, and the new global cycle-count theorem. Full original 1996 text was not available in this review.
3. Repair the numerical pass predicate and use nonzero exit status if a required diagnostic fails. Keep successful integration and sign agreement as separate fields.
4. Retain the distinction between explicit energy bounds and the existential full-theorem parameter threshold. The preliminary bound is not a certified numerical uniqueness threshold.

## Reproduction

Requires Python with numpy, scipy, and sympy. Versions used are in independent_results.json.
Extract the original submission and run:

    python independent_checks.py --bundle /path/to/evidence_press_wilhelm_heinrich_no_escape_v0_3 --output fresh_independent_results.json

The independent script uses the author's return JSON only as a comparison target; it does not import the author's solver for independent returns. It imports the numerical module only for the separately labelled mutation test. That mutation does not modify the original file.
Author reruns can be performed by invoking their individual scripts from the original bundle. Preserve submitted evidence before doing so: the scripts overwrite their own evidence JSON files.

## Files and limitations

submitted_evidence contains the supplied JSON files preserved before rerunning; rerun_evidence contains the newly generated author-script JSON files plus metadata. The logs record executions. SUBMISSION_SHA256SUMS is the original manifest; SHA256SUMS hashes this referee package.
No orbit meshes, original source papers, or manuscript modifications are included in this referee archive. The source meshes remain in the user's original bundle.
Floating-point checks are neither interval certificates nor exclusion of all cycles. Symbolic checks do not formalise invariant-manifold persistence, compact capture, or return-map smoothness. The written argument, not a finite simulation, supports the global theorem.
The literature check was bounded; failure to locate an earlier equivalent theorem does not establish priority. Current REF2029 guidance was checked; its detailed panel criteria were still described as forthcoming. The provisional star calibration therefore uses the explicitly labelled published REF2021 Main Panel B quality definitions as an interim benchmark.
