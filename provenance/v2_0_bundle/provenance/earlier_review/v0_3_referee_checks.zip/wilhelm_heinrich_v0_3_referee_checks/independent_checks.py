"""Independent algebra and numerical checks of Wilhelm--Heinrich v0.3.

This is not interval validation, an exhaustive cycle search, or formal proof.
The symbolic calculations and numerical algorithm are independently written;
the author's return routine is imported only in a labelled mutation test.
"""
from __future__ import annotations
import argparse, importlib.util, json, platform
from pathlib import Path
import numpy as np
import scipy
from scipy.integrate import solve_ivp
from scipy.optimize import brentq
from numpy.polynomial.legendre import leggauss
import sympy as sp


def exact_checks() -> dict:
    checks = []
    def zero(name, expression):
        residual = sp.simplify(sp.expand(expression))
        if residual != 0:
            raise AssertionError((name, residual))
        checks.append(name)
    x,y,z,a,b,r = sp.symbols('x y z a b r', positive=True)
    field = [r*x*(1-y), a*(z-y), b*(x-z)]
    Lie = lambda f: sum(sp.diff(f,q)*dq for q,dq in zip([x,y,z],field))
    B=a*b; sig=a+b; q=Lie(sp.log(y)); delta=r-sig
    zero('arbitrary-rate filter identity', B*x/y-(Lie(q)+q*q+sig*q+B))
    J = B*sp.log(x)-r*Lie(y)-r*sig*y+(r*sig-B)*sp.log(y)+r*q-q*q/2-B*x/y
    zero('arbitrary-rate cubic primitive',Lie(J)-(q**3-delta*q*q))
    t,S,d = sp.symbols('t S d')
    poly=sp.Poly((t+a)*(t-S/a)**2,t)
    av={0:1,1:0,2:S,3:d*S}
    expectation=sum(co*av[power[0]] for power,co in poly.terms())
    zero('moment support polynomial',expectation-((a+d)*S-S*S/a))

    u,v,w,e,nu=sp.symbols('u v w e nu',real=True)
    g=sp.exp(u)-1
    scalar_field=[v,w,-(a+b)*w-a*b*v-r*a*b*g]
    D=lambda f: sum(sp.diff(f,t)*dt for t,dt in zip([u,v,w],scalar_field))
    X,Y,Z=sp.exp(u),1-v/r,1-v/r-w/(r*a)
    for name,expr in [('X',D(X)-r*X*(1-Y)),('Y',D(Y)-a*(Z-Y)),('Z',D(Z)-b*(X-Z))]:
        zero('general scalar-to-chemical reconstruction '+name,expr)
    h=-g
    coeffs=[h]
    for j in range(1,4):
        residual=sp.expand(e*(sp.diff(h,u)*v+sp.diff(h,v)*h)+h+e*v+(1+nu*e*e)*g)
        hj=-sp.expand(residual).coeff(e,j)
        hj=sp.simplify(hj)
        coeffs.append(hj);h += e**j*hj
    expected=[-g,g*v,g*g-sp.exp(u)*v*v-nu*g,
        sp.exp(u)*v**3+(nu*sp.exp(u)-4*sp.exp(u)*g-g*g)*v]
    for j,(actual,reference) in enumerate(zip(coeffs,expected)):
        zero(f'recursively derived graph coefficient {j}',actual-reference)
    H0=v*v/2+g-u
    K=-sp.exp(2*u)/2+2*u*sp.exp(u)-u-u*u+nu*(sp.exp(u)-u)
    H=H0+e*v**3/3+e*e*(u*v*v+K-K.subs(u,0))
    drift=sp.expand(sp.diff(H,u)*v+sp.diff(H,v)*h)
    for j in range(3):zero(f'corrected-energy cancellation order {j}',drift.coeff(e,j))
    zero('third-order energy drift',drift.coeff(e,3)-(nu-4*sp.exp(u)*g+2*u*g)*v*v)
    theta,zz,kk=sp.symbols('theta zz kk',positive=True)
    factor=sp.sqrt(1-theta+theta*zz**2)*(1-theta+theta*kk/zz)
    zero('transport minimisation derivative',sp.diff(factor,zz)-theta*(1-theta)*(zz**3-kk)/(zz**2*sp.sqrt(1-theta+theta*zz**2)))
    # At nu=0 the exact characteristic polynomial is (e*lambda+1)(lambda^2+1).
    lam=sp.symbols('lam')
    char=e*lam**3+lam**2+e*lam+1+nu*e*e
    zero('Hopf characteristic factorisation',char.subs(nu,0)-(e*lam+1)*(lam*lam+1))
    eigen_nu=-sp.diff(char,nu)/sp.diff(char,lam)
    slope=sp.simplify(eigen_nu.subs({lam:sp.I,nu:0}))
    zero('exact slow-eigenvalue real-part derivative',sp.re(slope)-e**3/(2*(1+e*e)))
    return {'passed':len(checks),'checks':checks,'slow_graph_coefficients':[str(c) for c in coeffs],
            'exact_equilibrium_scaled_return_nu_derivative':'pi/(1+epsilon^2)'}


# Fixed Gauss--Legendre quadrature after a turning-point cosine substitution;
# this differs from the author's adaptive quadrature implementation.
_nodes,_weights=leggauss(512)
_theta=(_nodes+1)*np.pi/2
_weights=_weights*np.pi/2

def G(u):return np.expm1(u)-u

def moments(E:float):
    left=brentq(lambda u:G(u)-E,-E-2,0,xtol=1e-14)
    right=brentq(lambda u:G(u)-E,0,np.log(E+2)+3,xtol=1e-14)
    c=(left+right)/2;d=(right-left)/2
    uu=c+d*np.cos(_theta); vv=np.maximum(E-G(uu),np.finfo(float).tiny)
    jac=d*np.sin(_theta)
    return tuple(float(np.dot(_weights,jac*vv**p)) for p in [-.5,.5,1.5])

def selector_checks():
    records=[]
    for E in np.geomspace(1e-4,1e3,101):
        im,A,B=moments(float(E))
        sel=4*B/(3*A);slope=2-2*B*im/(3*A*A)
        records.append({'E':float(E),'selector':sel,'slope':slope})
    selected=[]
    for nu in [.25,1.,4.]:
        def target(E):
            _,A,B=moments(E);return 4*B/(3*A)-nu
        E=brentq(target,nu/2,1.25*nu,xtol=2e-13)
        selected.append({'nu':nu,'E':E})
    return {'scope':'finite floating-point check, not a proof of the selector inequality',
            'count':len(records),'minimum_slope':min(x['slope'] for x in records),
            'selected_energies':selected,'records':records}

def H2(u,v,e,nu):
    # Stabilised K(u)-K(0), algebraically identical to the manuscript.
    correction=-.5*np.expm1(2*u)+2*u*np.exp(u)-u-u*u+nu*(np.expm1(u)-u)
    return v*v/2+G(u)+e*v**3/3+e*e*(u*v*v+correction)

def independent_return(E:float,sigma:float,nu:float=1.):
    e=1/sigma;r=sigma+nu/sigma;a=2/(sigma+np.sqrt(sigma*sigma-4));b=1/a
    v0=np.sqrt(2*E);w0=-e*e*v0*v0+e**3*(v0**3+nu*v0)
    initial=[1.,1-v0/r,1-v0/r-w0/(r*a)]
    def rhs(t,state):
        x,y,z=state
        return [r*x*(1-y),a*(z-y),b*(x-z)]
    def section(t,state):return state[0]-1.
    section.direction=1.;section.terminal=True
    kw={'method':'DOP853','rtol':4e-13,'atol':4e-14,'max_step':min(.035,3/sigma)}
    start=solve_ivp(rhs,(0,1e-4),initial,**kw)
    if not start.success:raise RuntimeError(start.message)
    solution=solve_ivp(rhs,(1e-4,150),start.y[:,-1],events=section,**kw)
    if not solution.success or not len(solution.t_events[0]):raise RuntimeError('No return: '+solution.message)
    x,y,z=solution.y_events[0][0]
    u=np.log(x);v=r*(1-y)
    displacement=(H2(u,v,e,nu)-H2(0.,v0,e,nu))/e**3
    _,A,B=moments(E);M=nu*2*np.sqrt(2)*A-(2/3)*4*np.sqrt(2)*B
    return {'E':E,'sigma':sigma,'nu':nu,'method':'DOP853 in chemical coordinates',
            'scaled_displacement':float(displacement),'predicted':M,
            'sign_matches':bool(displacement*M>0),'return_time':float(solution.t_events[0][0])}

def validation_mutation(bundle:Path):
    spec=importlib.util.spec_from_file_location('author_return_trials_mutation',bundle/'code/return_trials.py')
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    genuine=module.moments
    module.moments=lambda E:tuple(-x for x in genuine(E))
    result=module.trial(.1,1.,32.)
    return {'scope':'deliberately reversed predictor; validation-control test, not scientific evidence',
            'sign_matches_prediction':result['sign_matches_prediction'],'passed':result['passed'],
            'defect_reproduced':bool(result['passed'] and not result['sign_matches_prediction'])}

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--bundle',type=Path,required=True)
    parser.add_argument('--output',type=Path,default=Path('independent_results.json'));args=parser.parse_args()
    results={'environment':{'python':platform.python_version(),'numpy':np.__version__,
             'scipy':scipy.__version__,'sympy':sp.__version__},'exact':exact_checks(),
             'selector':selector_checks()}
    author=json.loads((args.bundle/'evidence/return_trials.json').read_text())
    lookup={(x['E'],x['sigma']):x for x in author}
    returns=[]
    for E in [.1,3.,20.]:
        for sigma in [32.,64.,128.]:
            x=independent_return(E,sigma)
            reference=lookup[E,sigma]['scaled_displacement']
            x['author_scaled_displacement']=reference
            x['absolute_method_difference']=abs(x['scaled_displacement']-reference)
            x['relative_method_difference']=x['absolute_method_difference']/abs(reference)
            returns.append(x)
    results['independent_returns']=returns
    results['validation_mutation']=validation_mutation(args.bundle)
    args.output.write_text(json.dumps(results,indent=2)+'\n')
    print(json.dumps({'exact_passed':results['exact']['passed'],'selector_minimum':results['selector']['minimum_slope'],
          'selected_energies':results['selector']['selected_energies'],'independent_returns':len(returns),
          'all_return_signs_agree':all(x['sign_matches'] for x in returns),
          'maximum_relative_method_difference':max(x['relative_method_difference'] for x in returns),
          'validation_mutation':results['validation_mutation']},indent=2))

if __name__=='__main__':main()
